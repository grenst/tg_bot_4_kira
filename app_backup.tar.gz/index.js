require("./keepAlive"); // Keep-Alive сервер

require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");

const bot = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: true });
const CHANNEL_ID = process.env.CHAT_ID;

let questionsFormal = [
  "Ваш псевдоним",
  "Сколько вопросов Вы хотите?",
  "Сможете ли Вы скинуть ответы за 3 дня?",
  "Ваш юз",
  "Ваш тгк",
];

let questionsInformal = [
  "твой псевдоним",
  "сколько вопросов хочешь?",
  "сможешь скинуть ответы за 3 дня?",
  "твой юз",
  "твой тгк",
];

const users = {};

// Начало работы бота
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  users[chatId] = {
    step: 0,
    answers: [],
    isFormal: true,
    greeting: "",
    selectedOtherAge: false,
  };

  // Клавиатура для выбора обращения
  const greetingKeyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "на Вы", callback_data: "formal" }],
        [{ text: "можно на ты", callback_data: "informal" }],
      ],
    },
  };

  bot.sendMessage(chatId, "Как к Вам обращаться?", greetingKeyboard);
});

// Обработка нажатий на inline-клавиатуру (Выбор обращения и возраста)
bot.on("callback_query", (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const user = users[chatId];

  if (user.step === 0) {
    // Обработка выбранного обращения
    if (callbackQuery.data === "formal") {
      user.isFormal = true;
      user.greeting = "Вы"; // Сохраняем обращение
      bot.sendMessage(chatId, "Вы выбрали обращение на 'Вы'.");
    } else if (callbackQuery.data === "informal") {
      user.isFormal = false;
      user.greeting = "ты"; // Сохраняем обращение
      bot.sendMessage(chatId, "Вы выбрали обращение на 'ты'.");
    }

    // Переход к выбору возраста
    user.step += 1; // Шаг 1: выбор возраста
    const ageKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: "10", callback_data: "10" }],
          [{ text: "11", callback_data: "11" }],
          [{ text: "12", callback_data: "12" }],
          [{ text: "13", callback_data: "13" }],
          [{ text: "14", callback_data: "14" }],
          [{ text: "15", callback_data: "15" }],
          [{ text: "16", callback_data: "16" }],
          [{ text: "другой", callback_data: "другой" }],
        ],
      },
    };

    bot.sendMessage(chatId, "Выберите свой возраст:", ageKeyboard);
  } else if (user.step === 1) {
    // Обработка выбранного возраста
    const selectedAge = callbackQuery.data;

    // Если выбран вариант "другой"
    if (selectedAge === "другой") {
      user.selectedOtherAge = true; // Устанавливаем флаг selectedOtherAge
    }

    user.answers.push(selectedAge); // Сохраняем возраст
    bot.sendMessage(chatId, `Ваш возраст: ${selectedAge}`);

    // Переход к первому вопросу анкеты
    user.step += 1; // Шаг 2: начало анкеты
    const questions = user.isFormal ? questionsFormal : questionsInformal;

    // Клавиатура для отмены и начала заново
    const keyboard = {
      reply_markup: {
        keyboard: [
          [{ text: "отменить последний ответ" }],
          [{ text: "начать с начала" }],
        ],
        resize_keyboard: true,
        one_time_keyboard: false,
      },
    };

    bot.sendMessage(chatId, questions[0], keyboard); // Первый вопрос анкеты
  }
});

// Обработка ответов на вопросы
bot.on("message", (msg) => {
  const chatId = msg.chat.id;

  if (!users[chatId]) return;

  const user = users[chatId];
  const questions = user.isFormal ? questionsFormal : questionsInformal;

  // Обработка отмены последнего ответа
  if (msg.text === "отменить последний ответ") {
    if (user.step > 2) {
      user.step -= 1;
      user.answers.pop();
      bot.sendMessage(chatId, `Давайте вернёмся. ${questions[user.step - 2]}`);
    } else {
      bot.sendMessage(chatId, "Вы находитесь на первом шаге анкеты.");
    }
    return;
  }

  // Обработка начала заново
  if (msg.text === "начать с начала") {
    user.step = 2; // Возвращаемся к началу анкеты
    user.answers = user.answers.slice(0, 1); // Оставляем только возраст
    bot.sendMessage(chatId, "Начнём заново. " + questions[0]);
    return;
  }

  // Обработка ответов на вопросы анкеты
  if (user.step >= 2 && user.step < questions.length + 2) {
    const currentQuestionIndex = user.step - 2;

    // Проверка количества вопросов (если это соответствующий шаг)
    if (currentQuestionIndex === 1) {
      const numberOfQuestions = parseInt(msg.text);
      if (isNaN(numberOfQuestions) || numberOfQuestions > 7) {
        bot.sendMessage(chatId, "Можно лишь до семи вопросов. Введите снова:");
        return;
      }
      user.answers.push(msg.text);
    }
    // Проверка юзера (если это соответствующий шаг)
    else if (currentQuestionIndex === 3) {
      let username = msg.text;

      // Убираем https://t.me/ или http://t.me/
      if (username.startsWith("https://t.me/")) {
        username = username.replace("https://t.me/", "@");
      } else if (username.startsWith("http://t.me/")) {
        username = username.replace("http://t.me/", "@");
      } else if (!username.startsWith("@")) {
        // Добавляем @, если его нет
        username = "@" + username;
      }

      user.answers.push(username);
    } else {
      user.answers.push(msg.text);
    }

    user.step += 1;

    if (user.step < questions.length + 2) {
      bot.sendMessage(chatId, questions[user.step - 2]);
    } else {
      // Анкета завершена
      bot.sendMessage(
        chatId,
        "Спасибо! Ваша заявка принята. Ami скоро её рассмотрит ^_^",
      );

      // Определяем заголовок заявки
      const header = user.selectedOtherAge
        ? "Новая заявка (age ❗):"
        : "Новая заявка:";

      // Формирование сообщения с заявкой
      const userMessage = `
${header}
    0. Обращение: ${user.greeting}
    1. возраст: ${user.answers[0]}
    2. псевдоним: ${user.answers[1]}
    3. сколько вопросов: ${user.answers[2]}
    4. ответы за 3 дня: ${user.answers[3]}
    5. юз: ${user.answers[4]}
    6. тгк: ${user.answers[5]}
    `;

      bot
        .sendMessage(CHANNEL_ID, userMessage)
        .then(() => console.log("Заявка отправлена на рассмотрение ami"))
        .catch((error) => console.log("Ошибка отправки заявки:", error));

      delete users[chatId]; // Очистка данных после отправки заявки
    }
  }
});
